<?php

$conn = mysqli_connect("localhost", "root", "", "Productos");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //var_dump($_POST["codigo"]);

    $codigo = $_POST['codigo'] ?? '';
    $nombre = $_POST['nombre'] ?? '';
    $bodega = $_POST['bodega'] ?? '';
    $sucursal = $_POST['sucursal'   ] ?? '';
    $moneda = $_POST['moneda'] ?? '';
    $precio = $_POST['precio'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';
    $material = '';
    if (isset($_POST['material'])) {
        $material = implode(', ', $_POST['material']);
    }

    if ($codigo == '' || $nombre == '' || $bodega == '' || $precio == '') {
        echo "Faltan datos obligatorios";
        exit;
    }



    try {

        $sql = "INSERT INTO productos(codigo, nombre, bodega, sucursal, moneda, precio, materiales, descripcion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $codigo,
            $nombre,
            $bodega,
            $sucursal,
            $moneda,
            $precio,
            $material,
            $descripcion
        ]);
    } catch (Exception $e) {
        echo "error!:" . $e->getMessage();
    }


    echo "ok!";
}
?>

