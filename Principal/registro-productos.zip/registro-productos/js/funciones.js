// HTML 
document.addEventListener('DOMContentLoaded', function () {

    const btnGuardar = document.getElementById('btnGuardar');

    btnGuardar.addEventListener('click', function () {

        const codigo = document.getElementById('codigo').value.trim();
        if (codigo === '') {
            alert('El código del producto es obligatorio.');
            return;
        }

        const nombre = document.getElementById('nombre').value.trim();
        if (nombre.length < 3) {
            alert('El nombre debe tener al menos 3 caracteres.');
            return;
        }

        const bodega = document.getElementById('bodega').value;
        if (bodega === '') {
            alert('Debe seleccionar una bodega.');
            return;
        }


        const sucursal = document.getElementById('sucursal').value;
        if (sucursal === '') {
            alert('Debe seleccionar una sucursal.');
            return;
        }

        const moneda = document.getElementById('moneda').value;
        if (moneda === '') {
            alert('Debe seleccionar una moneda.');
            return;
        }

        const precio = document.getElementById('precio').value.trim();
        if (precio === '' || isNaN(precio) || precio <= 0) {
            alert('Ingrese un precio válido.');
            return;
        }

        const materiales = document.querySelectorAll('input[name="material[]"]:checked');
        if (materiales.length < 2) {
            alert('Debe seleccionar al menos dos materiales.');
            return;
        }

        const descripcion = document.getElementById('descripcion').value.trim();
        if (descripcion.length < 10) {
            alert('La descripción debe tener al menos 10 caracteres.');
            return;
        }

        const xhr = new XMLHttpRequest();

        var formData = new FormData();
        formData.append("codigo", codigo);
        formData.append("nombre", nombre);
        formData.append("bodega", bodega);
        formData.append("sucursal", sucursal);
        formData.append("moneda", moneda);
        formData.append("precio", precio);
        formData.append("materiales", materiales);
        formData.append("materiales", materiales);

        xhr.onload = function () {
            if (xhr.status === 200) { // Check for successful status codes
                console.log('Success:', JSON.parse(xhr.responseText)); // Parse and handle the response
            } else {
                console.error('Error:', xhr.statusText);
            }
        };

        xhr.onerror = function () {
            console.error('Request failed');
        };

        xhr.open('POST', 'http://localhost/registro-productos/php/dao.php', true); // Open a POST request asynchronously
        //xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8'); // Set the content type header
        xhr.send(formData);


        alert('Producto registrado correctamente 🎉');

    });

});
